#pragma once

#include <semaphore.h>

/**
 * @brief Общие константы.
 */
enum
{
    PICT_COUNT = 5, ///< Количество картин в галерее.
    PROC_MAX_COUNT = 50, ///< Максимальное количество посетителей галереи.
    PICT_VIEWRS_MAX_COUNT = 10 ///< Максимальное количество пос-лей на 1 картину
};


// Обработчики вызовов функций системного API

#define ERR_RES_HANDLER( res, expr, msg ) \
    if( ( ( res ) = ( expr ) ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

#define ERR_HANDLER( expr, msg ) \
    if( ( expr ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

/// @brief Имя именованного семафора для доступа к галерее
static const char *SEM_GLR_NAME = "/gallery_sem";

/// @brief Имя общей памяти галереи
static const char *SHARED_MEM_NAME = "/shar_gallery";

/// @brief Имена именованных семафороф для доступа к картинам галереи
static const char *SEM_PICT_NAME[ PICT_COUNT ] =
{
    "/sem_0_pic",
    "/sem_1_pic",
    "/sem_2_pic",
    "/sem_3_pic",
    "/sem_4_pic",
};

/// @brief Представление галереи в общей памяти
typedef struct
{
    /// @brief Наименования картин
    const char *mPictureNames[ PICT_COUNT ];
} sGallery;


/// @brief Управляемые вахтером ресурсы
typedef struct
{
    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;

    /// @brief Семафоры доступа к картинам
    sem_t *mPictQueuSem[ PICT_COUNT ];

    /// @brief Семафор доступа к галерее
    sem_t *mSemGallery;

} sManagedRes;

/// @brief Управляемые посетителем ресурсы
typedef struct
{
    /// @brief Семафор доступа к галерее
    sem_t *mSemGallery;

    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;
} sVisitRes;
