#!/bin/bash

./watcher > log/watcher.txt &

for i in {1..70}
do
    ./visitor $i > log/visitor_$i.txt &
    
done

echo "Don't forget to kill the Watcher with SIGINT"
