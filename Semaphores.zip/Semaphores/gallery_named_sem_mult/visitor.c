/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);


/* --- Фуникции посетителей --- */

/**
 * @brief Основная функция посетителя.
 * @param [in] id Порядковый номер посетителя
 */
static void visitorProcessing( int id );

/**
 * @brief Вход в галерею.
 * @param [in] id Номер посетителя
 * @return True - успех
 */
static bool enterTheGallery(int id, sVisitRes *resrs);

/**
 * @brief Выход из галереи.
 * @param [in] id Номер посетителя
 */
static void exitTheGallery(int id, sVisitRes *resrs);

/**
 * @brief Все ли картины просмотрены.
 * @param [in] viewd Массив флагов просмотренных картин.
 * @return true - все картины просмотрены, иначе false.
 */
static bool isAllViewd( bool *viewd );


/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}

/* --- Начало выполнения программы ------------------------------------------ */

int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 2;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    const int visId = atoi( argv[ 1 ] );

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);

    visitorProcessing( visId );

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s <vis_id>\n"
           "Where <vis_id> - visitor's integer identificator\n", argv[ 0 ] );
    printf("Exit - Ctrl+C\n");
}

static void visitorProcessing( int id )
{
    // Вход в галерею
    sVisitRes resrs;
    if( !enterTheGallery( id, &resrs ) )
    {
        LOG("ID %d\tOkay.. Bye!", id);
        return;
    }

    srand( time( NULL ) + id );
    bool viewdPict[ PICT_COUNT ] = { 0 };
    while( !isAllViewd( viewdPict ) && !is_done )
    {
        int desiredPict = rand() % ( PICT_COUNT );
        LOG( "ID %d\tI want to see pict num %d!", id, desiredPict );

        // Очередь к картине
        sem_t *pictQueueSem = sem_open( SEM_PICT_NAME[ desiredPict ], 0 );
        if( SEM_FAILED == pictQueueSem )
        {
            perror( "sem_open pict queue" );
            return;
        }

        /// @todo Ожидаение, просмотр..

        sem_wait( pictQueueSem );

        LOG( "ID %d\tWow its a %s", id, resrs.mpGallery->mPictureNames[ desiredPict ] );

        // максимальное время ожидания/просмотра картины
        enum { MAX_TIME_S = 4 };
        int waitnSecnds = rand() % ( MAX_TIME_S + 1 );

        // Просмотр картины
        sleep( waitnSecnds );
        viewdPict[ desiredPict ] = true;

        sem_post( pictQueueSem );
        sem_close( pictQueueSem );

        LOG( "ID %d\tGot it!", id );
    }


    // Выход из галереи
    exitTheGallery( id, &resrs );
}

static bool enterTheGallery(int id, sVisitRes *resrs)
{
    // Количество попыток входа
    int attempts = 10;

    // Ожидания открытия галереи aka создания семафора
    while( SEM_FAILED == ( resrs->mSemGallery = sem_open( SEM_GLR_NAME, 0 ) ) && --attempts )
    {
        LOG( "ID %d\tI'm waiting for the art gallery to open...", id );
        sleep( 1 );
    }

    if( 0 == attempts )
    {
        perror( "sem_open" );
        return false;
    }

    sem_wait( resrs->mSemGallery );

    // Открытие общей памяти
    resrs->mShareMemFd = shm_open( SHARED_MEM_NAME, O_RDONLY, 0666 );
    if( resrs->mShareMemFd < 0 )
    {
        perror( "shm_open" );
        return false;
    }

    resrs->mpGallery = mmap( 0, sizeof( sGallery ),
                             PROT_READ, MAP_SHARED,
                             resrs->mShareMemFd, 0 );
    if( MAP_FAILED == resrs->mpGallery )
    {
        perror( "mmap" );
        return false;
    }

    // Теперь семафор захвачен, память доступна, посетитель внутри
    LOG( "ID %d\tIm In!", id );
    return true;
}

static void exitTheGallery(int id, sVisitRes *resrs)
{
    ERR_HANDLER( sem_post( resrs->mSemGallery ), "sem_post" );

    ERR_HANDLER( sem_close( resrs->mSemGallery ), "sem_close" );

    munmap( ( void * )resrs->mpGallery, sizeof( sGallery ) );
    close( resrs->mShareMemFd );

    // Ушел изх галереи, ресурсы освобождены
    LOG( "ID %d\tThats been fine! Bye!", id );
}

static bool isAllViewd( bool *viewd )
{
    bool res = true;

    for( int i = 0; i < PICT_COUNT; ++i )
    {
        if( !viewd[ i ] )
        {
            res = false;
            break;
        }
    }

    return res;
}
