/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);

/* --- Фуникции вахтера --- */

/// @brief Открытие галереи
static void openGallery( sManagedRes *resrs );

/**
 * @brief Заполнение галереи.
 * @param [in] glr Объект галереи в общей памяти
 */
static void fillGallery( sGallery *glr );

/// @brief Закрытие галереи
static void closeGallery( sManagedRes *resrs );

/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}

/* --- Начало выполнения программы ------------------------------------------ */


int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 1;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);

    LOG( "WATCHMAN:\tOpening gallery..." );

    sManagedRes resource;
    openGallery( &resource );


    LOG( "WATCHMAN:\tGallery is opened!" );
    while( !is_done )
    {
        sleep( 1 );
    }

    LOG( "WATCHMAN:\tClosing gallery..." );
    closeGallery( &resource );

    LOG( "WATCHMAN:\tGallery is closed!" );

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s\n\n"
           "visitors should ipc via:\n"
           "shared memory %s\n"
           "gallery unix named semaphore %s\n",
           argv[ 0 ], SHARED_MEM_NAME, SEM_GLR_NAME );

    for( int i = 0; i < PICT_COUNT; ++i )
    {
        printf("picture %d unix named semaphore %s\n", i + 1, SEM_PICT_NAME[ i ] );
    }

    printf("Exit - Ctrl+C\n");

}

static void openGallery( sManagedRes *resrs )
{
    // Открытие общей памяти
    ERR_RES_HANDLER( resrs->mShareMemFd,
                     shm_open( SHARED_MEM_NAME, O_CREAT | O_EXCL | O_RDWR, 0666 ),
                     "shm_open" );

    // Размер
    ERR_HANDLER( ftruncate( resrs->mShareMemFd, sizeof( sGallery ) ),
                 "ftruncate" );

    if( MAP_FAILED == ( resrs->mpGallery = mmap( 0,
                                                 sizeof( sGallery ),
                                                 PROT_READ | PROT_WRITE,
                                                 MAP_SHARED,
                                                 resrs->mShareMemFd,
                                                 0 ) ) )
    {
        perror( "mmap" );
        exit( 1 );
    }

    // Заполнение картин
    fillGallery( resrs->mpGallery );

    // Очереди к картинам
    for( int pict = 0; pict < PICT_COUNT; ++pict )
    {
        if( SEM_FAILED ==
                ( resrs->mPictQueuSem[ pict ] = sem_open( SEM_PICT_NAME[ pict ],
                                                          O_CREAT | O_EXCL,
                                                          0666,
                                                          PICT_VIEWRS_MAX_COUNT ) ) )
        {
            perror( "sem_open" );
            exit( 1 );
        }
    }

    // Создание семафора галереи aka Открытие галереи
    if( SEM_FAILED == ( resrs->mSemGallery = sem_open( SEM_GLR_NAME,
                                                       O_CREAT | O_EXCL,
                                                       0666,
                                                       PROC_MAX_COUNT ) ) )
    {
        perror( "sem_open" );
        exit( 1 );
    }
}

static void fillGallery( sGallery *glr )
{
    snprintf(glr->mPictureNames[ 0 ], PICT_MAX_NAME_SIZE, "Forest");
    snprintf(glr->mPictureNames[ 1 ], PICT_MAX_NAME_SIZE, "Sea");
    snprintf(glr->mPictureNames[ 2 ], PICT_MAX_NAME_SIZE, "Window");
    snprintf(glr->mPictureNames[ 3 ], PICT_MAX_NAME_SIZE, "Birds");
    snprintf(glr->mPictureNames[ 4 ], PICT_MAX_NAME_SIZE, "Field");
}

static void closeGallery( sManagedRes *resrs )
{
    munmap( resrs->mpGallery, sizeof( sGallery ) );
    close( resrs->mShareMemFd );
    shm_unlink( SHARED_MEM_NAME );

    sem_close( resrs->mSemGallery );
    sem_unlink( SEM_GLR_NAME );


    for( int pict = 0; pict < PICT_COUNT; ++pict )
    {
        sem_close( resrs->mPictQueuSem[ pict ] );
        sem_unlink( SEM_PICT_NAME[ pict ] );
    }

}

