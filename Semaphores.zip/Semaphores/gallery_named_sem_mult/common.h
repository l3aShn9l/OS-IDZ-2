#pragma once

#include <semaphore.h>

/**
 * @brief Общие константы.
 */
enum
{
    PICT_COUNT = 5, ///< Количество картин в галерее.
    PROC_MAX_COUNT = 50, ///< Максимальное количество посетителей галереи.
    PICT_VIEWRS_MAX_COUNT = 10, ///< Максимальное количество пос-лей на 1 картину
    PICT_MAX_NAME_SIZE = 10 ///< Максимальная длина имени картины
};


// Обработчики вызовов функций системного API

#define ERR_RES_HANDLER( res, expr, msg ) \
    if( ( ( res ) = ( expr ) ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

#define ERR_HANDLER( expr, msg ) \
    if( ( expr ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

/// @brief Имя именованного семафора для доступа к галерее
static const char *SEM_GLR_NAME = "/gallery_sem";

/// @brief Имя общей памяти галереи
static const char *SHARED_MEM_NAME = "/shar_gallery";

/// @brief Имена именованных семафороф для доступа к картинам галереи
static const char *SEM_PICT_NAME[ PICT_COUNT ] =
{
    "/sem_0_pic",
    "/sem_1_pic",
    "/sem_2_pic",
    "/sem_3_pic",
    "/sem_4_pic",
};

/// @brief Представление галереи в общей памяти
typedef struct
{
    /// @brief Наименования картин
    char mPictureNames[ PICT_COUNT ][ PICT_MAX_NAME_SIZE ];
} sGallery;


/// @brief Управляемые вахтером ресурсы
typedef struct
{
    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;

    /// @brief Семафоры доступа к картинам
    sem_t *mPictQueuSem[ PICT_COUNT ];

    /// @brief Семафор доступа к галерее
    sem_t *mSemGallery;

} sManagedRes;

/// @brief Управляемые посетителем ресурсы
typedef struct
{
    /// @brief Семафор доступа к галерее
    sem_t *mSemGallery;

    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;
} sVisitRes;


/// @brief Макрос для логирования
#define LOG_HELPER(fmt, ...) \
{ \
    time_t sysTime = time(NULL); \
    struct tm tm = *localtime( &sysTime ); \
    printf("%02d:%02d:%02d ", tm.tm_hour, tm.tm_min, tm.tm_sec ); \
    printf(fmt "%s\n", __VA_ARGS__); \
    fflush(stdout); \
}

#define LOG(...) LOG_HELPER(__VA_ARGS__, "")
