#pragma once

#include <semaphore.h>

/**
 * @brief Общие константы.
 */
enum
{
    PICT_COUNT = 5, ///< Количество картин в галерее.
    PROC_MAX_COUNT = 50, ///< Максимальное количество посетителей галереи.
    PICT_VIEWRS_MAX_COUNT = 10 ///< Максимальное количество пос-лей на 1 картину
};


// Обработчики вызовов функций системного API

#define ERR_RES_HANDLER( res, expr, msg ) \
    if( ( ( res ) = ( expr ) ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

#define ERR_HANDLER( expr, msg ) \
    if( ( expr ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

/// @brief Путь для доступа к ключу семафора sys v
const char *SYS_V_PATH_SEM = "/tmp/sys_v_path_sem";

enum
{
    SEM_GALLERY,
    SEM_PICT_1,
    SEM_PICT_2,
    SEM_PICT_3,
    SEM_PICT_4,
    SEM_PICT_5,

    SEM_COUNT
};

const char *SYS_V_SHARED_MEM_PATH = "/tmp/shared";

/// @brief Представление галереи в общей памяти
typedef struct
{
    /// @brief Наименования картин
    const char *mPictureNames[ PICT_COUNT ];
} sGallery;


/// @brief Управляемые ресурсы
typedef struct
{
    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;

    /// @brief Идентификатор семафоров Sys V
    int semId;
} sManagedRes;
