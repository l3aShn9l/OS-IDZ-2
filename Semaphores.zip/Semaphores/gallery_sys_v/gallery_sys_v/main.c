/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);


static inline void semOperation( int semId, int semNum, int semOp )
{
    struct sembuf sb = { semNum, semOp, 0 };
    semop( semId, &sb, 1 );
}

static inline void semLock( int semId, int semNum )
{
    semOperation( semId, semNum, -1 );
}

static inline void semUnLock( int semId, int semNum )
{
    semOperation( semId, semNum, 1 );
}


/* --- Фуникции вахтера --- */

/// @brief Открытие галереи
static void openGallery( sManagedRes *resrs );

/**
 * @brief Заполнение галереи.
 * @param [in] glr Объект галереи в общей памяти
 */
static void fillGallery( sGallery *glr );

/// @brief Закрытие галереи
static void closeGallery( sManagedRes *resrs );

/* --- Фуникции посетителей --- */

/**
 * @brief Основная функция посетителя.
 * @param [in] id Порядковый номер посетителя
 */
static void visitorProcessing(int id);

/**
 * @brief Вход в галерею.
 * @param [in] id Номер посетителя
 */
static void enterTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Выход из галереи.
 * @param [in] id Номер посетителя
 */
static void exitTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Все ли картины просмотрены.
 * @param [in] viewd Массив флагов просмотренных картин.
 * @return true - все картины просмотрены, иначе false.
 */
static bool isAllViewd( bool *viewd );


/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}


/* --- Начало выполнения программы ------------------------------------------ */

int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 2;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    const int visitorsCount = atoi( argv[ 1 ] );

    if( visitorsCount <= 0 )
    {
        printf("Error visitors count.\n");
        usage( argc, argv );
        exit(1);
    }

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);


    // Посетители
    pid_t *visitors = calloc( visitorsCount, sizeof( pid_t ) );
    memset( visitors, 0, visitorsCount * sizeof( pid_t ) );

    // Создание процессов-посетителей
    for( int vis = 0; vis < visitorsCount; ++vis )
    {
        pid_t pid;
        ERR_RES_HANDLER( pid, fork(), "fork" );

        if( 0 == pid )
        {
            // Выполнение основной функции посетителя
            visitorProcessing( vis );
            exit( 0 );
        }
        else
        {
            // Добавление посетителя в массив
            visitors[ vis ] = pid;
        }
    }

    printf("WATCHMAN:\tOpening gallery...\n");
    fflush(stdout);
    sManagedRes resource;
    openGallery( &resource );
    printf("WATCHMAN:\tGallery is opened!\n");
    fflush(stdout);

    for( int vis = 0; vis < visitorsCount; ++vis )
    {
        int status = 0;
        waitpid( visitors[ vis ], &status, 0 );
    }

    free( visitors );

    printf("WATCHMAN:\tClosing gallery...\n");
    fflush(stdout);
    closeGallery( &resource );
    printf("WATCHMAN:\tGallery is closed!\n");
    fflush(stdout);

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s <num visitors>\n"
           "where <num visitors> must be greater than 0\n", argv[ 0 ] );
}

static void openGallery( sManagedRes *resrs )
{
    // Открытие общей памяти
    key_t shmemKey = 0;
    ERR_RES_HANDLER( shmemKey, ftok( SYS_V_SHARED_MEM_PATH, 'm' ), "ftok" );
    ERR_RES_HANDLER( resrs->mShareMemFd,
                     shmget(shmemKey, sizeof ( sGallery ), 0666 | IPC_CREAT),
                     "shmget" );

    if( MAP_FAILED == ( resrs->mpGallery = shmat(resrs->mShareMemFd, (void *)0, 0 ) ) )
    {
        perror( "shmat" );
        exit( 1 );
    }

    // Заполнение картин
    fillGallery( resrs->mpGallery );

    key_t sysVKey = ftok( SYS_V_PATH_SEM, 1 );
    resrs->semId = semget( sysVKey, SEM_COUNT, 0666 | IPC_CREAT );

    semctl( resrs->semId, SEM_GALLERY, SETVAL, PROC_MAX_COUNT );
    for( int sem = SEM_PICT_1; sem < SEM_COUNT; ++sem )
    {
        semctl( resrs->semId, sem, SETVAL, PICT_VIEWRS_MAX_COUNT );
    }
}

static void fillGallery( sGallery *glr )
{
    glr->mPictureNames[0] = "Forest";
    glr->mPictureNames[1] = "Sea";
    glr->mPictureNames[2] = "Window";
    glr->mPictureNames[3] = "Birds";
    glr->mPictureNames[4] = "Field";
}

static void closeGallery( sManagedRes *resrs )
{
    ERR_HANDLER( shmdt( resrs->mpGallery ), "shmdt" );

    semctl(resrs->semId, 0, IPC_RMID, 0 );
    shmctl(resrs->mShareMemFd, IPC_RMID, NULL );
}

static void visitorProcessing( int id )
{
    // Вход в галерею
    sManagedRes resrs;
    enterTheGallery( id, &resrs );

    srand( time( NULL ) + id );
    bool viewdPict[ PICT_COUNT ] = { 0 };
    while( !isAllViewd( viewdPict ) && !is_done  )
    {
        int desiredPict = rand() % ( PICT_COUNT );
        printf( "ID %d\tI want to see picn num %d !\n", id, desiredPict );
        fflush(stdout);

        // Очередь к картине
        semLock( resrs.semId, desiredPict );

        printf( "ID %d\tWow its a %s\n", id, resrs.mpGallery->mPictureNames[ desiredPict ] );
        fflush(stdout);

        // максимальное время ожидания/просмотра картины
        enum { MAX_TIME_S = 4 };
        int waitnSecnds = rand() % ( MAX_TIME_S + 1 );

        // Просмотр картины
        sleep( waitnSecnds );
        viewdPict[ desiredPict ] = true;

        semUnLock( resrs.semId, desiredPict );

        printf( "ID %d\tGot it!\n", id );
        fflush(stdout);
    }


    // Выход из галереи
    exitTheGallery( id, &resrs );
}

static void enterTheGallery(int id, sManagedRes *resrs)
{
    // Количество попыток входа
    int attempts = 10;

    key_t sysVKey = ftok( SYS_V_PATH_SEM, 1 );

    int semId = 0;

    // Ожидания открытия галереи aka создания семафора
    while( ( ( semId = semget( sysVKey, SEM_COUNT, 0666 ) ) < 0 ) &&
           attempts-- )
    {
        printf( "ID %d\tI'm waiting for the art gallery to open...\n", id );
        fflush(stdout);
        sleep( 1 );
    }

    if( 0 == attempts )
    {
        perror( "sem_open" );
        return;
    }

    resrs->semId = semId;

    semLock( resrs->semId, SEM_GALLERY );

    // Открытие общей памяти
    key_t shmemKey = ftok( SYS_V_SHARED_MEM_PATH, 'm' );
    resrs->mShareMemFd = shmget( shmemKey, sizeof ( sGallery ), 0666 );
    if( resrs->mShareMemFd < 0 )
    {
        perror( "shm_open" );
        return;
    }

    if( MAP_FAILED == ( resrs->mpGallery = shmat(resrs->mShareMemFd, (void *)0, 0 ) ) )
    {
        perror( "shmat" );
        exit( 1 );
    }

    // Теперь семафор захвачен, память доступна, посетитель внутри
    printf( "ID %d\tIm In!\n", id);
    fflush(stdout);
}

static void exitTheGallery(int id, sManagedRes *resrs)
{
    semUnLock( resrs->semId, SEM_GALLERY );

    ERR_HANDLER( shmdt( resrs->mpGallery ), "shmdt" );

    // Ушел изх галереи, ресурсы освобождены
    printf( "ID %d\tThats been fine! Bye!\n", id );
    fflush(stdout);
}

static bool isAllViewd( bool *viewd )
{
    bool res = true;

    for( int i = 0; i < PICT_COUNT; ++i )
    {
        if( !viewd[ i ] )
        {
            res = false;
            break;
        }
    }

    return res;
}
