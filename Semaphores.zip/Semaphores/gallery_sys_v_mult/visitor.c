/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);


static inline void semOperation( int semId, int semNum, int semOp )
{
    struct sembuf sb =
    {
        .sem_num = semNum,
        .sem_op = semOp,
        .sem_flg = 0
    };

    semop( semId, &sb, 1 );
}

static inline void semLock( int semId, int semNum )
{
    semOperation( semId, semNum, -1 );
}

static inline void semUnLock( int semId, int semNum )
{
    semOperation( semId, semNum, 1 );
}


/* --- Фуникции посетителей --- */

/**
 * @brief Основная функция посетителя.
 * @param [in] id Порядковый номер посетителя
 */
static void visitorProcessing(int id);

/**
 * @brief Вход в галерею.
 * @param [in] id Номер посетителя
 */
static bool enterTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Выход из галереи.
 * @param [in] id Номер посетителя
 */
static void exitTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Все ли картины просмотрены.
 * @param [in] viewd Массив флагов просмотренных картин.
 * @return true - все картины просмотрены, иначе false.
 */
static bool isAllViewd( bool *viewd );


/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}


/* --- Начало выполнения программы ------------------------------------------ */

int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 2;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    const int visId = atoi( argv[ 1 ] );

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);


    visitorProcessing( visId );

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s <vis_id>\n"
           "Where <vis_id> - visitor's integer identificator\n", argv[ 0 ] );
    printf("Exit - Ctrl+C\n");
}

static void visitorProcessing( int id )
{
    // Вход в галерею
    sManagedRes resrs;
    if( !enterTheGallery( id, &resrs ) )
    {
        LOG("ID %d\tOkay.. Bye!", id);
        return;
    }

    srand( time( NULL ) + id );
    bool viewdPict[ PICT_COUNT ] = { 0 };
    while( !isAllViewd( viewdPict ) && !is_done  )
    {
        int desiredPict = rand() % ( PICT_COUNT );
        LOG( "ID %d\tI want to see pict num %d!", id, desiredPict );

        // Очередь к картине
        semLock( resrs.semId, desiredPict );

        LOG( "ID %d\tWow its a %s", id, resrs.mpGallery->mPictureNames[ desiredPict ] );

        // максимальное время ожидания/просмотра картины
        enum { MAX_TIME_S = 4 };
        int waitnSecnds = rand() % ( MAX_TIME_S + 1 );

        // Просмотр картины
        sleep( waitnSecnds );
        viewdPict[ desiredPict ] = true;

        semUnLock( resrs.semId, desiredPict );

        LOG( "ID %d\tGot it!", id );
    }


    // Выход из галереи
    exitTheGallery( id, &resrs );
}

static bool enterTheGallery(int id, sManagedRes *resrs)
{
    // Количество попыток входа
    int attempts = 10;

    key_t sysVKey = ftok( SYS_V_PATH_SEM, 1 );

    int semId = 0;

    // Ожидания открытия галереи aka создания семафора
    while( ( ( semId = semget( sysVKey, SEM_COUNT, 0666 ) ) < 0 ) &&
           --attempts )
    {
        LOG( "ID %d\tI'm waiting for the art gallery to open...", id );
        sleep( 1 );
    }

    if( 0 == attempts )
    {
        perror( "sem_open" );
        return false;
    }

    resrs->semId = semId;

    semLock( resrs->semId, SEM_GALLERY );

    // Открытие общей памяти
    key_t shmemKey = ftok( SYS_V_SHARED_MEM_PATH, 'm' );
    resrs->mShareMemFd = shmget( shmemKey, sizeof ( sGallery ), 0666 );
    if( resrs->mShareMemFd < 0 )
    {
        perror( "shm_open" );
        exit( 1 );
    }

    if( MAP_FAILED == ( resrs->mpGallery = shmat(resrs->mShareMemFd, (void *)0, 0 ) ) )
    {
        perror( "shmat" );
        exit( 1 );
    }

    // Теперь семафор захвачен, память доступна, посетитель внутри
    LOG( "ID %d\tIm In!", id);

    return true;
}

static void exitTheGallery(int id, sManagedRes *resrs)
{
    semUnLock( resrs->semId, SEM_GALLERY );

    ERR_HANDLER( shmdt( resrs->mpGallery ), "shmdt" );

    // Ушел изх галереи, ресурсы освобождены
    LOG( "ID %d\tThats been fine! Bye!", id );
    fflush(stdout);
}

static bool isAllViewd( bool *viewd )
{
    bool res = true;

    for( int i = 0; i < PICT_COUNT; ++i )
    {
        if( !viewd[ i ] )
        {
            res = false;
            break;
        }
    }

    return res;
}
