/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);

/* --- Фуникции вахтера --- */

/// @brief Открытие галереи
static void openGallery( sManagedRes *resrs );

/**
 * @brief Заполнение галереи.
 * @param [in] glr Объект галереи в общей памяти
 */
static void fillGallery( sGallery *glr );

/// @brief Закрытие галереи
static void closeGallery( sManagedRes *resrs );

/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}


/* --- Начало выполнения программы ------------------------------------------ */

int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 1;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);




    LOG( "WATCHMAN:\tOpening gallery..." );

    sManagedRes resource;
    openGallery( &resource );


    LOG( "WATCHMAN:\tGallery is opened!" );
    while( !is_done )
    {
        sleep( 1 );
    }

    LOG( "WATCHMAN:\tClosing gallery..." );
    closeGallery( &resource );

    LOG( "WATCHMAN:\tGallery is closed!" );

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s\n"
           "Needed files: %s and %s"
           "Exit - Ctrl+C\n", argv[ 0 ], SYS_V_PATH_SEM, SYS_V_SHARED_MEM_PATH );
}

static void openGallery( sManagedRes *resrs )
{
    // Открытие общей памяти
    key_t shmemKey = 0;
    ERR_RES_HANDLER( shmemKey, ftok( SYS_V_SHARED_MEM_PATH, 'm' ), "ftok" );
    ERR_RES_HANDLER( resrs->mShareMemFd,
                     shmget(shmemKey, sizeof ( sGallery ), 0666 | IPC_CREAT),
                     "shmget" );

    if( MAP_FAILED == ( resrs->mpGallery = shmat(resrs->mShareMemFd, (void *)0, 0 ) ) )
    {
        perror( "shmat" );
        exit( 1 );
    }

    // Заполнение картин
    fillGallery( resrs->mpGallery );

    key_t sysVKey = ftok( SYS_V_PATH_SEM, 1 );
    resrs->semId = semget( sysVKey, SEM_COUNT, 0666 | IPC_CREAT );

    semctl( resrs->semId, SEM_GALLERY, SETVAL, PROC_MAX_COUNT );
    for( int sem = SEM_PICT_1; sem < SEM_COUNT; ++sem )
    {
        semctl( resrs->semId, sem, SETVAL, PICT_VIEWRS_MAX_COUNT );
    }
}

static void fillGallery( sGallery *glr )
{
    snprintf(glr->mPictureNames[ 0 ], PICT_MAX_NAME_SIZE, "Forest");
    snprintf(glr->mPictureNames[ 1 ], PICT_MAX_NAME_SIZE, "Sea");
    snprintf(glr->mPictureNames[ 2 ], PICT_MAX_NAME_SIZE, "Window");
    snprintf(glr->mPictureNames[ 3 ], PICT_MAX_NAME_SIZE, "Birds");
    snprintf(glr->mPictureNames[ 4 ], PICT_MAX_NAME_SIZE, "Field");
}

static void closeGallery( sManagedRes *resrs )
{
    ERR_HANDLER( shmdt( resrs->mpGallery ), "shmdt" );

    semctl(resrs->semId, 0, IPC_RMID );
    shmctl(resrs->mShareMemFd, IPC_RMID, NULL );
}
