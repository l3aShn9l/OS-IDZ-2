#pragma once

#include <semaphore.h>

/**
 * @brief Общие константы.
 */
enum
{
    PICT_COUNT = 5, ///< Количество картин в галерее.
    PROC_MAX_COUNT = 50, ///< Максимальное количество посетителей галереи.
    PICT_VIEWRS_MAX_COUNT = 10, ///< Максимальное количество пос-лей на 1 картину
    PICT_MAX_NAME_SIZE = 10 ///< Максимальная длина имени картины
};


// Обработчики вызовов функций системного API

#define ERR_RES_HANDLER( res, expr, msg ) \
    if( ( ( res ) = ( expr ) ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

#define ERR_HANDLER( expr, msg ) \
    if( ( expr ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

/// @brief Путь для доступа к ключу семафора sys v
const char *SYS_V_PATH_SEM = "/tmp/sys_v_path_sem";

enum
{
    SEM_GALLERY,
    SEM_PICT_1,
    SEM_PICT_2,
    SEM_PICT_3,
    SEM_PICT_4,
    SEM_PICT_5,

    SEM_COUNT
};

const char *SYS_V_SHARED_MEM_PATH = "/tmp/shared";

/// @brief Представление галереи в общей памяти
typedef struct
{
    /// @brief Наименования картин
    char mPictureNames[ PICT_COUNT ][ PICT_MAX_NAME_SIZE ];
} sGallery;


/// @brief Управляемые ресурсы
typedef struct
{
    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Представление галереи
    sGallery *mpGallery;

    /// @brief Идентификатор семафоров Sys V
    int semId;
} sManagedRes;

/// @brief Макрос для логирования
#define LOG_HELPER(fmt, ...) \
{ \
    time_t sysTime = time(NULL); \
    struct tm tm = *localtime( &sysTime ); \
    printf("%02d:%02d:%02d ", tm.tm_hour, tm.tm_min, tm.tm_sec ); \
    printf(fmt "%s\n", __VA_ARGS__); \
    fflush(stdout); \
}

#define LOG(...) LOG_HELPER(__VA_ARGS__, "")
