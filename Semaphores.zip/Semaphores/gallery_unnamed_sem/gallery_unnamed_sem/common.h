#pragma once

#include <semaphore.h>

/**
 * @brief Общие константы.
 */
enum
{
    PICT_COUNT = 5, ///< Количество картин в галерее.
    PROC_MAX_COUNT = 50, ///< Максимальное количество посетителей галереи.
    PICT_VIEWRS_MAX_COUNT = 10 ///< Максимальное количество пос-лей на 1 картину
};


// Обработчики вызовов функций системного API

#define ERR_RES_HANDLER( res, expr, msg ) \
    if( ( ( res ) = ( expr ) ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

#define ERR_HANDLER( expr, msg ) \
    if( ( expr ) < 0 ) { \
        perror( ( msg ) ); \
        exit( 1 ); }

/// @brief Имя общей памяти галереи
static const char *SHARED_MEM_NAME = "/shard_gallery";


/// @brief Представление галереи в общей памяти
typedef struct
{
    /// @brief Наименования картин
    const char *mPictureNames[ PICT_COUNT ];
} sGallery;

/// @brief Общая память для процессов
typedef struct
{
    /// @brief Представление галереи
    sGallery mGallery;

    /// @brief Семафор доступа в галерею
    sem_t mSemGallery;

    /// @brief Семафоры доступа к картинам
    sem_t mSemPictures[ PICT_COUNT ];

} sSharedMemory;


/// @brief Управляемые ресурсы
typedef struct
{
    /// @brief Дескриптор общей памяти
    int mShareMemFd;

    /// @brief Общая память
    sSharedMemory *mpShared;
} sManagedRes;



///// @brief Управляемые посетителем ресурсы
//typedef struct
//{
//    /// @brief Семафор доступа к галерее
//    sem_t *mSemGallery;

//    /// @brief Дескриптор общей памяти
//    int mShareMemFd;

//    /// @brief Представление галереи
//    sGallery *mpGallery;
//} sVisitRes;
