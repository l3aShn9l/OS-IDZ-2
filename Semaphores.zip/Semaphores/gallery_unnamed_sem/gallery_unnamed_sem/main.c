/* --- Подключение заголовочных файлов -------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <unistd.h>

// Общие определения и типы
#include "common.h"

/* --- Объявления функций --------------------------------------------------- */

/* --- Общее --- */

/**
 * @brief Подсказка по использованию приложения.
 */
static void usage(int argc, char **argv);

/* --- Фуникции вахтера --- */

/// @brief Открытие галереи
static void openGallery( sManagedRes *resrs );

/**
 * @brief Заполнение галереи.
 * @param [in] glr Объект галереи в общей памяти
 */
static void fillGallery( sGallery *glr );

/// @brief Закрытие галереи
static void closeGallery( sManagedRes *resrs );

/* --- Фуникции посетителей --- */

/**
 * @brief Основная функция посетителя.
 * @param [in] id Порядковый номер посетителя
 */
static void visitorProcessing( int id, sManagedRes *resrs );

/**
 * @brief Вход в галерею.
 * @param [in] id Номер посетителя
 */
static void enterTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Выход из галереи.
 * @param [in] id Номер посетителя
 */
static void exitTheGallery(int id, sManagedRes *resrs);

/**
 * @brief Все ли картины просмотрены.
 * @param [in] viewd Массив флагов просмотренных картин.
 * @return true - все картины просмотрены, иначе false.
 */
static bool isAllViewd( bool *viewd );


/**
 * @brief Завершение процессов по сигналу
 */
bool is_done = false;
void signal_handler( int var )
{
    ( void )var;
    is_done = true;
}


/* --- Начало выполнения программы ------------------------------------------ */

int main( int argc, char **argv)
{
    // Валидация ввода
    const static int ARGC_CNT = 2;
    if( ARGC_CNT != argc )
    {
        printf("Error syntax.\n");
        usage( argc, argv );
        exit(1);
    }

    const int visitorsCount = atoi( argv[ 1 ] );

    if( visitorsCount <= 0 )
    {
        printf("Error visitors count.\n");
        usage( argc, argv );
        exit(1);
    }

    struct sigaction act;
    memset(&act, 0, sizeof(act));
    act.sa_handler = signal_handler;
    sigemptyset(&act.sa_mask);
    sigaddset(&act.sa_mask, SIGINT);
    sigaction(SIGINT, &act, NULL);


    // Посетители
    pid_t *visitors = calloc( visitorsCount, sizeof( pid_t ) );
    memset( visitors, 0, visitorsCount * sizeof( pid_t ) );


    printf("WATCHMAN:\tOpening gallery...\n");
    fflush(stdout);
    sManagedRes resource;
    openGallery( &resource );
    printf("WATCHMAN:\tGallery is opened!\n");
    fflush(stdout);


    // Создание процессов-посетителей
    for( int vis = 0; vis < visitorsCount; ++vis )
    {
        pid_t pid;
        ERR_RES_HANDLER( pid, fork(), "fork" );

        if( 0 == pid )
        {
            // Выполнение основной функции посетителя
            visitorProcessing( vis, &resource );
            exit( 0 );
        }
        else
        {
            // Добавление посетителя в массив
            visitors[ vis ] = pid;
        }
    }

    for( int vis = 0; vis < visitorsCount; ++vis )
    {
        int status = 0;
        waitpid( visitors[ vis ], &status, 0 );
    }

    free( visitors );

    printf("WATCHMAN:\tClosing gallery...\n");
    fflush(stdout);
    closeGallery( &resource );
    printf("WATCHMAN:\tGallery is closed!\n");
    fflush(stdout);

    return 0;
}

/* --- Определения функций -------------------------------------------------- */


static void usage(int argc, char **argv)
{
    (void)argc;
    printf("Usage: %s <num visitors>\n"
           "where <num visitors> must be greater than 0\n", argv[ 0 ] );
}

static void openGallery( sManagedRes *resrs )
{
    // Открытие общей памяти
    ERR_RES_HANDLER( resrs->mShareMemFd,
                     shm_open( SHARED_MEM_NAME, O_CREAT | O_EXCL | O_RDWR, 0666 ),
                     "shm_open" );

    // Размер
    ERR_HANDLER( ftruncate( resrs->mShareMemFd, sizeof( sSharedMemory ) ),
                 "ftruncate" );

    if( MAP_FAILED == ( resrs->mpShared = mmap( 0,
                                                sizeof( sSharedMemory ),
                                                PROT_READ | PROT_WRITE,
                                                MAP_SHARED,
                                                resrs->mShareMemFd,
                                                0 ) ) )
    {
        perror( "mmap" );
        exit( 1 );
    }

    // Заполнение картин
    fillGallery( &resrs->mpShared->mGallery );

    // Очереди к картинам
    for( int pict = 0; pict < PICT_COUNT; ++pict )
    {

        ERR_HANDLER( sem_init( &resrs->mpShared->mSemPictures[ pict ], 1, PICT_VIEWRS_MAX_COUNT ),
                     "sem_init" );
    }

    // Создание семафора галереи aka Открытие галереи
    ERR_HANDLER( sem_init( &resrs->mpShared->mSemGallery, 1, PROC_MAX_COUNT ),
                 "sem_init" );
}

static void fillGallery( sGallery *glr )
{
    glr->mPictureNames[ 0 ] = "Forest";
    glr->mPictureNames[ 1 ] = "Sea";
    glr->mPictureNames[ 2 ] = "Window";
    glr->mPictureNames[ 3 ] = "Birds";
    glr->mPictureNames[ 4 ] = "Field";
}

static void closeGallery( sManagedRes *resrs )
{
    sem_destroy( &resrs->mpShared->mSemGallery );

    for( int pict = 0; pict < PICT_COUNT; ++pict )
    {
        sem_destroy( &resrs->mpShared->mSemPictures[ pict ] );
    }

    munmap( resrs->mpShared, sizeof( sSharedMemory ) );
    close( resrs->mShareMemFd );
    shm_unlink( SHARED_MEM_NAME );

}

static void visitorProcessing(int id , sManagedRes *resrs )
{
    // Вход в галерею
    enterTheGallery( id, resrs );

    srand( time( NULL ) + id );
    bool viewdPict[ PICT_COUNT ] = { 0 };
    while( !isAllViewd( viewdPict ) && !is_done )
    {
        int desiredPict = rand() % ( PICT_COUNT );
        printf( "ID %d\tI want to see picn num %d !\n", id, desiredPict );
        fflush(stdout);

        sem_wait( &resrs->mpShared->mSemPictures[ desiredPict ] );

        printf( "ID %d\tWow its a %s\n",
                id,
                resrs->mpShared->mGallery.mPictureNames[ desiredPict ] );
        fflush(stdout);

        // максимальное время ожидания/просмотра картины
        enum { MAX_TIME_S = 4 };
        int waitnSecnds = rand() % ( MAX_TIME_S + 1 );

        // Просмотр картины
        sleep( waitnSecnds );
        viewdPict[ desiredPict ] = true;

        sem_post( &resrs->mpShared->mSemPictures[ desiredPict ] );

        printf( "ID %d\tGot it!\n", id );
        fflush(stdout);
    }


    // Выход из галереи
    exitTheGallery( id, resrs );
}

static void enterTheGallery(int id, sManagedRes *resrs)
{
    ERR_HANDLER( sem_wait( &resrs->mpShared->mSemGallery ),
                 "sem_wait" );

    // Теперь семафор захвачен, память доступна, посетитель внутри
    printf( "ID %d\tIm In!\n", id );
    fflush(stdout);
}

static void exitTheGallery(int id, sManagedRes *resrs)
{
    ERR_HANDLER( sem_post( &resrs->mpShared->mSemGallery ), "sem_post" );

    munmap( ( void * )resrs->mpShared, sizeof( sSharedMemory ) );
    close( resrs->mShareMemFd );

    // Ушел изх галереи, ресурсы освобождены
    printf( "ID %d\tThats been fine! Bye!\n", id );
    fflush(stdout);
}

static bool isAllViewd( bool *viewd )
{
    bool res = true;

    for( int i = 0; i < PICT_COUNT; ++i )
    {
        if( !viewd[ i ] )
        {
            res = false;
            break;
        }
    }

    return res;
}
